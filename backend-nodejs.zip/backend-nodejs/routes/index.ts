import {NextFunction, Request, Response} from "express";
import Learning from "../database/postgresql";
import express from "express";

const router = express.Router();

router.get("/", (req: Request, res: Response, next: NextFunction) => {
  Learning.findAll()
    .then((learning) => {
      res.json(learning);
    })
    .catch((err) => {
      return next(err);
    });
});

router.post("/", (req: Request, res: Response, next: NextFunction) => {
  Learning.create(req.body)
    .then((learning) => {
      res.json(learning);
    })
    .catch((err) => {
      return next(err);
    });
});

router.put("/", (req: Request, res: Response, next: NextFunction) => {
  Learning.update(req.body  , { where: { id: req.body.id } })
    .then((learning) => {
      res.json(learning);
    })
    .catch((err) => {
      return next(err);
    });
});

router.delete("/", (req: Request, res: Response, next: NextFunction) => {
  Learning.destroy({ where: { id: req.body.id } })
    .then((learning) => {
      res.json(learning);
    })
    .catch((err) => {
      return next(err);
    });
});

export default router;

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const postgresql_1 = __importDefault(require("../database/postgresql"));
const express_1 = __importDefault(require("express"));
const router = express_1.default.Router();
router.get("/", (req, res, next) => {
    postgresql_1.default.findAll()
        .then((learning) => {
        res.json(learning);
    })
        .catch((err) => {
        return next(err);
    });
});
router.post("/", (req, res, next) => {
    postgresql_1.default.create(req.body)
        .then((learning) => {
        res.json(learning);
    })
        .catch((err) => {
        return next(err);
    });
});
router.put("/", (req, res, next) => {
    postgresql_1.default.update(req.body, { where: { id: req.body.id } })
        .then((learning) => {
        res.json(learning);
    })
        .catch((err) => {
        return next(err);
    });
});
router.delete("/", (req, res, next) => {
    postgresql_1.default.destroy({ where: { id: req.body.id } })
        .then((learning) => {
        res.json(learning);
    })
        .catch((err) => {
        return next(err);
    });
});
exports.default = router;

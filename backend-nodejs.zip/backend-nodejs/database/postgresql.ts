import { Sequelize, DataTypes } from "sequelize";
import dotenv from "dotenv";
dotenv.config();

const pool = new Sequelize('postgres://user:root@localhost:5432/LearningDb');
//uri : 'postgres://username:password@host:port/database'

const Learning = pool.define(
  'Learning',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    isnew: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true,
    },
    learn: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    due: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    recto: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    verso: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: 'learning',
    timestamps: false,
    freezeTableName: true,
  }
);

export default Learning;

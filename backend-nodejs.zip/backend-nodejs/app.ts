import express, { Express, Router } from "express";
import bodyParser from "body-parser";
import cors from "cors";
import router from "./routes/index";

const app: Express = express();
app.use(cors());
app.use(bodyParser.json());
const port = 3000;

app.use("/", router);

app.listen(port, () => {
  console.log(`[server]: Server is running at http://localhost:${port}`);
});
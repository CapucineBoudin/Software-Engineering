import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from "@angular/material/button";
import {MatDialogModule, MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {MatSlideToggleModule} from "@angular/material/slide-toggle";
import {MatCardModule} from "@angular/material/card";

export interface FlashcardDialogData {
  name: string;
  recto: string;
  verso: string;
}

@Component({
  selector: 'app-flashcard',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatSlideToggleModule, MatCardModule],
  templateUrl: './flashcard.component.html',
  styleUrl: './flashcard.component.css'
})

export class FlashcardComponent {
  constructor(
    public dialogRef: MatDialogRef<FlashcardComponent>,
    @Inject(MAT_DIALOG_DATA) public data: FlashcardDialogData,
    ) {}
  showRecto: boolean = true
  onNoClick(): void {
    this.dialogRef.close();
  }

  onAnswerClick(): void {
    this.showRecto = !this.showRecto;
  }
}

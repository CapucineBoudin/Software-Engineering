import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';
import { MatIconModule } from "@angular/material/icon";
import { MatButtonModule } from "@angular/material/button";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatTabsModule } from "@angular/material/tabs";
import { MatTableModule } from "@angular/material/table";
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AddDialog } from "./add/add.component";
import {FlashcardComponent} from "./flashcard/flashcard.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    MatTabsModule,
    MatTableModule,
    MatDialogModule,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'App Page';
  learningData: any[] = [];
  displayedColumns: string[] = ['name', 'new', 'learn', 'due', 'actions'];

  constructor(public dialog: MatDialog) {}

  openDialog(): void {
    const dialogRef = this.dialog.open(AddDialog, {
      width: 'auto',
      data: {name: '', recto: '', verso: ''}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if (result) {
        fetch('http://localhost:3000/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(result)
        })
          .then(response => response.json())
          .then(data => {
            console.log('Success:', data);
            this.displayAllLearningData();
          })
          .catch(error => console.error('Error:', error));
      }
    });
  }

  openFlashcard(data: any): void {
    console.log(data);
    const dialogRef = this.dialog.open(FlashcardComponent, {
      width: 'auto',
      data: {name: data.name, recto: data.recto, verso: data.verso}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.updateFlashcard(data);
    });
  }

  deleteFlashcard(id: number): void {
    console.log(id);
    fetch('http://localhost:3000/', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({id: id})
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        this.displayAllLearningData();
      })
      .catch(error => console.error('Error:', error));
  }

  updateFlashcard(data: any): void {
    console.log(data);
    fetch('http://localhost:3000/', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({id:data.id, isnew: false, learn: (data.learn + 1)})
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        this.displayAllLearningData();
      })
      .catch(error => console.error('Error:', error));
  }

  ngOnInit() {
    this.displayAllLearningData();
  }

  displayAllLearningData() {
    fetch('http://localhost:3000/')
      .then(response => response.json())
      .then(data => {
        this.learningData = data;
        console.log('Success:', data);
      })
      .catch(error => console.error('Error:', error));
  }
}
